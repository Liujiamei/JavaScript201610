//更改城市 UPDATE_CITY
export const UPDATE_CITY = 'UPDATE_CITY';


export const SAVE_ID = 'SAVE_ID';